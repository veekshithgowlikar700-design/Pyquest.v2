# Polytech Quest: Python + Physics (Year 1, Mid-1)
Android WebView app, same structure as SnakeByte. UI is `app/src/main/assets/index.html`.
- Learn path: lessons (read, formulas, 🔊 read aloud) then a quiz (MCQ, true/false, typed numbers), 3 lives, XP, daily goal, streak.
- Physics: 11 units, 52 lessons (the 9 SBTET units plus extra lessons, Elasticity, and Fluids). Python: 10 units, 29 lessons (basics through strings, collections, modules, files, exceptions, OOP, NumPy and Matplotlib). Add more by editing the `PY` array (Python) or `U` array (Physics). New lessons added in v1.1 are in the block marked `NEWCONTENT` in index.html.
- Fully offline. Progress is stored on the device (`polytech_quest_v1`).

## Make the APK
1. Create a GitHub repo and upload everything in this folder (keep `.github`).
2. Actions tab > "Build PolytechQuest APK" > Run workflow (it also runs on every push to main).
3. Download `PolytechQuest-v1-debug.apk` from Releases and install it on your phone.
